# 1.创建`dev`分支

创建并切换

`git checkout -b dev`

=>`git switch -c dev`-- 更好理解

=>

```shell
git branch dev #创建
git checkout dev #切换
```



# 2.切换主分支

`git checkout master`

# 3.合并分支

合并分支至当前分支

`git merge dev`

# 4.删除分支

`git branch -d dev`