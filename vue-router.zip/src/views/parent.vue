<template>
    <div>
        Parent页面
        <!-- 渲染路由视图 -->
    <router-view></router-view>
    </div>
</template>
<script>
export default {
    
}
</script>
<style>

</style>