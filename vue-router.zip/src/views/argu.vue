<template>
    <div>
        动态路由，参数{{$route.params.name}}
    </div>
</template>
<script>
export default {
    
}
</script>
<style>

</style>